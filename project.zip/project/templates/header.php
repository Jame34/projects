<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MM</title>
</head>
<body>
<header style="background-image: url('assets/images/background_image.png'); background-size: cover; background-repeat: no-repeat; background-position: center; height: auto; overflow: hidden;">
    <div style="height: calc(100% - 50px); overflow: hidden;">
        <h1>
            <img src="assets/images/mm_logo.png" alt="MM" style="max-width: 100px; height: auto; display: block; margin: 0 auto;">
        </h1>
    </div>
</header>
