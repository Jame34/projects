<footer>
<footer style="background: linear-gradient(135deg, #01184e, #003d75); padding: 5px; text-align: center;">
    <p style="color: white;">© 2024 知識圖譜系統</p>
    <div>
        <a href="https://www.facebook.com" target="_blank">
            <img src="assets\images\facebook.png" alt="Facebook" style="width: 50px; height: 50px; margin-right: 10px;">
        </a>
        <a href="https://twitter.com" target="_blank">
            <img src="assets\images\twitter.png" alt="Twitter" style="width: 50px; height: 50px; margin-right: 10px;">
        </a>
        <a href="https://www.linkedin.com" target="_blank">
            <img src="assets\images\linkedin.png" alt="LinkedIn" style="width: 50px; height: 50px; margin-right: 10px;">
        </a>
        <a href="https://www.instagram.com" target="_blank">
            <img src="assets\images\instagram.png" alt="Instagram" style="width: 50px; height: 50px; margin-right: 10px;">
        </a>
    </div>
</footer>
</body>
</html>
